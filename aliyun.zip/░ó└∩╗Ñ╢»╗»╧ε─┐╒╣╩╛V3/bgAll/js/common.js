$(document).ready(function(){
    $(".fakeloader").fakeLoader({
        timeToHide: 1000,
        bgColor:"#000",
        spinner:"spinner5"
    });
});
