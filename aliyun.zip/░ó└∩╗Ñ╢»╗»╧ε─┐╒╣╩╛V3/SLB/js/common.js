$(document).ready(function(){
    $(".fakeloader").fakeLoader({
        timeToHide: 1000,
        bgColor:"#333",
        spinner:"spinner5"
    });
});
