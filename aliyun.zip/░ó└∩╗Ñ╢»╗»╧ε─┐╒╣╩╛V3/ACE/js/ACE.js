(function(){
		$(".main-center-text>p").eq(0).show();
        $(".main-center-list>div").eq(0).show();
	$('.main-left-list ul li').click(function(){
		if ($(this).hasClass("active")) {
			return;
		};
		$(".main-left-list>ul>li").removeClass("active").addClass("twinkle")
		var a=$(this).index();
		if (a>=3) {
			$(".main-left-list>ul>li").slice(3).removeClass("twinkle").addClass("active");
			a=3;
		}else{
			$(this).removeClass("twinkle").addClass("active");
		};
		$(".main-left-text>p").hide();
        $(".main-left-text>p").eq(a).show();
        $(".main-center-text>p").hide();
        $(".main-center-list>div").hide();
    	$(".main-center-text>p").eq(a).show();
    	$(".main-center-list>div").eq(a).show();
	})
})()