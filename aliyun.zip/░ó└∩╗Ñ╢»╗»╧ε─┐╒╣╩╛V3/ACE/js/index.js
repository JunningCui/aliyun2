/* roll Start */
(function  () {
    var num=1;
    window.setInterval(function(){
        $("#chart>div").eq(num).show().siblings().hide();
        num++;
        num==8?num=0:void 0;
    },2000)
})();


/* roll End */
/* nav Start */
//window.onload=function(){console.clear()};
(function () {
    var num=0
    $('.nav_ecs li').eq(0).children(".shili_light").hide();
    
    $('.nav_ecs li').click(function () {
        if ((!$(".main>section").eq($(this).index()).is(':hidden'))&&$(this).index()!=3) {
            console.log(4)
            return;
        };
       if (num!=1) {
             var marquee=$("#dataStream marquee");
            for (var i = 0; i < marquee.length-3; i++) {
                marquee.eq(i)[0].stop();
            };
        };
        $(this).children("img").removeClass("rotate");
        $(this).siblings().children("img").addClass("rotate");
        $(this).children("span").eq(1).hide();
        $(this).siblings().children().show();
        if($(this).index()==3){
            $("#question>.question").show().siblings().hide();
            $(".main>section").hide();
            $(".main>section").eq($(this).index()).show();
        }else if($(this).index()==2){
            $(".main>section").hide();
            $(".main>section").eq($(this).index()).show();
            $(".main-info").addClass("zoomIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    $(this).removeClass('zoomIn animated');
                });
            num==0?$("#element_id").kxbdMarquee({direction:"right"}):void 0;
            num++;
        }else if($(this).index()==1){
            $(".main>section").hide();
            $(".main>section").eq($(this).index()).show();
            var marquee=$("#dataStream marquee");           
            for (var i = 0; i < marquee.length-3; i++) {
                marquee.eq(i)[0].start();
            };

            setTimeout(function(){
                $(".left-out>marquee").show();
                for (var i = 0; i < $(".left-out>marquee").length; i++) {
                    $(".left-out>marquee").eq(i)[0].start();
                };
            },1500)
            
        }else{
            $(".main>section").hide();
            $(".main>section").eq($(this).index()).show()
        }
        //console.clear()

    })
})();
/* nav End */
/* question Start */
(function () {
    $(".answer-box>.yes").click(function(){
        var num=0;
        var num2=0
        if(num==num2){
            num++;
            $(this).parent().parent().hide().siblings().hide();
            $("#question>.no").show();
            $("#question>.no>.line-chart").hide();
            $("#question>.no>.line-chart>.wrong").hide();
            $(".no>.robot-box>.robot").hide();
            $(".no>.more-info>p").hide();
            $(".no>.again").hide()
            $("#question>.no>.line-chart").show().addClass("rollIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                $(this).removeClass("rollIn animated");
            });
            timer=setTimeout(function () {
                $("#question>.no>.line-chart>.wrong").show().addClass("zoomIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    $(this).removeClass('zoomIn animated');
                });
                $(".no>.robot-box>.robot").show().addClass("bounceInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                    $(this).removeClass('bounceInDown animated');
                });
                $(".no>.more-info>p").show().addClass("lightSpeedIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                      $(this).removeClass('lightSpeedIn animated');
                });
                $(".no>.again").show().addClass("rubberBand animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
                      $(this).removeClass('rubberBand animated');
                      num2++
                });
            },2000)
        }
    });
    $(".answer-box>.no").click(function(){
        $(this).parent().parent().hide().siblings().hide();
        $("#question>.yes").show();
        $(".yes h3").addClass("rollIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            $(this).removeClass();
        });
        $(".yes>.thank>p").addClass("flipInY animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            $(this).removeClass();
        });
        $(".yes>.robot").addClass("bounceInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            $(this).removeClass("bounceInDown animated");
        });
        $(".yes>.more-info>p").addClass("lightSpeedIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            $(this).removeClass();
        });
         $(".yes>.more-info-1").addClass("bounceInLeft animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
            $(this).removeClass("bounceInLeft animated");
        });
    })
})();
$(".no>.again").click(function  () {
    $('.nav_ecs li').eq(3).click();
})